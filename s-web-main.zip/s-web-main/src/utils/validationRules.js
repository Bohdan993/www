export const validationForm = [
  {name: {required: true}},
  {email: {email: true}},
]