export const content = {
  products: {
    title: "Our Products",
    data: [
      {
        title: "Renguin Slide: Meet Ollie",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with ownery claws in your leg. Prow?? ew ",
        img: "products-1.png",
      },
      {
        title: "Renguin Slide: Meet Ollie",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with ow Kitty claws in your leg. Prow?? ew dog you drink from the toilet, yum yum warm milk hotter pls, ouch dsadasdddadafsdfsdfsdfsdfsdfdf  dsawdasdf",
        img: "products-1.png",
      },
      {
        title: "Renguin Slide: Meet Ollie",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with ownery claws in your leg. Prow?? ew dog you drink from the toilet, yum yum warm milk hotter pls, ouch",
        img: "products-1.png",
      },
      {
        title: "Renguin Slide: Meet Ollie",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with ow Kitty claws in your leg. Prow?? ew dog you drink from the toilet, yum yum warm milk hotter pls, ouch",
        img: "products-1.png",
      },
      {
        title: "Renguin Slide: Meet Ollie",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with ownery claws in your leg. Prow?? ew dog you drink from the toilet, yum yum warm milk hotter pls, ouch",
        img: "products-1.png",
      },
      {
        title: "Renguin Slide: Meet Ollie",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with ow Kitty claws in your leg. Prow?? ew dog you drink from the toilet, yum yum warm milk hotter pls, ouch",
        img: "products-1.png",
      },
    ],
  },
  statistic: {
    title: "Statistic",
    countries: "20+",
    categories: {
      count: "12+",
      tags: [
        {
          name: "SaaS",
          score: "8%",
        },
        {
          name: "E-com",
          score: "32%",
        },
        {
          name: "Crypto",
          score: "24%",
        },
        {
          name: "Fintech",
          score: "16%",
        },
        {
          name: "Gamedev",
          score: "13%",
        },
        {
          name: "Tourism",
          score: "7%",
        },
        {
          name: "Fintech",
          score: "16%",
        },
        {
          name: "Gamedev",
          score: "13%",
        },
        {
          name: "Tourism",
          score: "7%",
        },
        {
          name: "E-com",
          score: "32%",
        },
        {
          name: "Crypto",
          score: "24%",
        },
        {
          name: "Fintech",
          score: "16%",
        },
      ],
    },
    ownProjects: "12",
    rated: "100%",
    projects: "300+",
    experience: "6+",
  },
  portfolio: {
    title: "Portfolio",
    data: [
      {
        title: "Healthcare Service",
        description: "Steal raw zucchini off",
        img: "portfolio-1.png",
        tags: ["React", "CSS", "HTML"],
      },
      {
        title: "Healthcare Service",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with  ose the door.Steal raw zucchini off kitchen counter",
        img: "portfolio-1.png",
        tags: ["React", "CSS", "HTML"],
      },
      {
        title: "Healthcare Service",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with  ose the door ",
        img: "portfolio-1.png",
        tags: [
          "React",
          "CSS",
          "HTML",
          "React",
          "CSS",
          "HTML",
          "React",
          "CSS",
          "HTML",
        ],
      },
      {
        title: "Healthcare Service",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with  ose the door.",
        img: "portfolio-1.png",
        tags: ["React", "CSS", "HTML"],
      },
      {
        title: "Healthcare Service",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with  ose the door.",
        img: "portfolio-1.png",
        tags: ["React", "CSS", "HTML"],
      },
      {
        title: "Healthcare Service",
        description:
          "Steal raw zucchini off kitchen counter chase red laser dot love to play with  ose the door.",
        img: "portfolio-1.png",
        tags: ["React", "CSS", "HTML"],
      },
    ],
  },
  skills: {
    title: "Skills",
    data: [
      [
        {
          id: 1,
          title: "Javascript",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "javascript.svg",
        },
        {
          id: 2,
          title: "Mongodb",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "mongodb.svg",
        },
        {
          id: 3,
          title: "Jquery",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "jquery.svg",
        },
        {
          id: 4,
          title: "Unity",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "unity.svg",
        },
      ],
      [
        {
          id: 5,
          title: "Graphql",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "graphql.svg",
        },
        {
          id: 6,
          title: "Ios",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "ios.svg",
        },
        {
          id: 7,
          title: "Html5",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "html5.svg",
        },
        {
          id: 8,
          title: "Firebase",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "firebase.svg",
        },
        {
          id: 9,
          title: "Css3",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "css3.svg",
        },
      ],
      [
        {
          id: 10,
          title: "Typescript",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "typescript.svg",
        },
        {
          id: 11,
          title: "Csharp",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "csharp.svg",
        },
        {
          id: 12,
          title: "Express",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "express.svg",
        },
        {
          id: 13,
          title: "Nodedotjs",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "nodedotjs.svg",
        },
      ],
      [
        {
          id: 14,
          title: "Android",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "android.svg",
        },
        {
          id: 15,
          title: "Mysql",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "mysql.svg",
        },
        {
          id: 16,
          title: "React",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "react.svg",
        },
        {
          id: 17,
          title: "Blender",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "blender.svg",
        },
        {
          id: "hidden",
        },
      ],
    ],
  },
  skillsMobile: {
    title: "Skills",
    data: [
      [
        {
          id: 1,
          title: "Javascript",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "javascript.svg",
        },
        {
          id: 2,
          title: "Mongodb",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "mongodb.svg",
        },
        {
          id: "hidden",
        },
      ],
      [
        {
          id: 3,
          title: "Graphql",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "graphql.svg",
        },
        {
          id: 4,
          title: "Ios",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "ios.svg",
        },
        {
          id: 5,
          title: "Html5",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "html5.svg",
        },
        {
          id: "hidden",
        },
      ],
      [
        {
          id: 6,
          title: "Csharp",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "csharp.svg",
        },
        {
          id: 7,
          title: "Express",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "express.svg",
        },
        {
          id: 8,
          title: "Nodedotjs",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "nodedotjs.svg",
        },
      ],
      [
        {
          id: 9,
          title: "Mysql",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "mysql.svg",
        },
        {
          id: 10,
          title: "Jquery",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "jquery.svg",
        },
        {
          id: 11,
          title: "React",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "react.svg",
        },
        {
          id: "hidden",
        },
      ],
      [
        {
          id: 12,
          title: "Unity",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "unity.svg",
        },
        {
          id: 13,
          title: "Blender",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "blender.svg",
        },
        {
          id: 14,
          title: "Typescript",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "typescript.svg",
        },
      ],
      [
        {
          id: 15,
          title: "Css3",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "css3.svg",
        },
        {
          id: 16,
          title: "Firebase",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "left",
          img: "firebase.svg",
        },
        {
          id: 17,
          title: "Android",
          description:
            "is a markup language used for structuring and presenting content on the World Wide Web",
          direction: "right",
          img: "android.svg",
        },
        {
          id: "hidden",
        },
      ],
    ],
  },
  feedback: {
    title: "Feedback",
    data: [
      {
        name: "Tany & steve",
        position: "Project managers",
        company: "Iconist",
        description:
          "I have known Roman for a while, during which time he worked on developing a complex mobile app catering to thousands of users worldwide. \n\nMy experience working with him has been very positive. He is highly skilled in programming and has added massive value to my project by showing deep understanding and providing good ideas for improvement. \n\nRoman works effectively to create stable new features and fixes bugs quickly. He is a very nice guy, responds to all my questions, and is a person you can rely on.",
      },
      {
        name: "Samuel",
        position: "Project managers",
        company: "Screenly",
        description:
          "Roman did a great job on the assigned tasks. He executed the tasks quickly and correctly. He also  was great at communicating during the process. 5 stars. I look forward  to hiring Roman again!",
      },
      {
        name: "Dom",
        position: "Project managers",
        company: "Screenly",
        description:
          "Roman did an amazing job creating a new website design using SASS/Bootstrap and we are extremely happy with his work. \n\nHe communicates really well, provides quality work and sticks to given timelines.  We really enjoyed working with Roman and can highly recommend him.",
      },
      {
        name: "Sarah",
        position: "Self employed",
        description:
          "This is our third project with Roman. He delivered a great design and I enjoyed working with him.",
      },
      {
        name: "Jenny",
        position: "Project managers",
        company: "Twik",
        description:
          "Roman always goes the extra mile to make the project successful.",
      },
    ],
  },
  team: {
    title: "Team",
    data: [
      {
        firstName: "Roman",
        secondName: "Svistel",
        img: "rsvistel-team.png",
        position: "Front-End Dev",
        location: ["pl-location.svg", "ua-location.svg"],
        color: "#FCBA04",
      },
      {
        firstName: "Vladimir",
        secondName: "Putin",
        img: "vputin-team.png",
        position: "Vladimir Putin",
        location: ["ru-location.svg"],
        color: "#CBFF8C",
      },
      {
        firstName: "Roman",
        secondName: "Svistel",
        img: "rsvistel-team.png",
        position: "Front-End Dev",
        location: ["pl-location.svg", "ua-location.svg"],
        color: "#FCBA04",
      },
      {
        firstName: "Arthur",
        secondName: "Svistel",
        img: "asvistel-team.png",
        position: "HTML & CSS Coder",
        location: ["la-location.svg"],
        color: "#CBFF8C",
      },
      {
        firstName: "Roman",
        secondName: "Svistel",
        img: "rsvistel-team.png",
        position: "Front-End Dev",
        location: ["pl-location.svg", "ua-location.svg"],
        color: "#FCBA04",
      },
      {
        firstName: "Marko",
        secondName: "Svistel",
        img: "asvistel-team.png",
        position: "HTML & CSS Coder",
        location: ["la-location.svg"],
        color: "#CBFF8C",
      },
    ],
  },
  blog: {
    title: "Blog",
    data: [
      {
        title: "Unity game dev",
        description: "Lorem Ipsum",
        img: "blog-1.png",
        link: "See cases using Unity",
      },
      {
        title: "Unity game dev",
        description:
          "Lorem Ipsum is simply dummy is simply dummy text of the printing and typesetting . Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ",
        img: "blog-2.png",
        link: "See cases using Unity",
      },
      {
        title: "Unity game dev",
        description:
          "Lorem Ipsum is simply dummy is simply dummy text of the printing and typesetting",
        img: "blog-3.png",
        link: "See cases using Unity",
      },
      {
        title: "Unity game dev",
        description:
          "Lorem Ipsum is simply dummy is simply dummy text of the printing and typesetting",
        img: "blog-4.png",
        link: "See cases using Unity",
      },
      {
        title: "Unity game dev",
        description:
          "Lorem Ipsum is simply dummy is simply dummy text of the printing and typesetting",
        img: "blog-1.png",
        link: "See cases using Unity",
      },
      {
        title: "Unity game dev",
        description:
          "Lorem Ipsum is simply dummy is simply dummy text of the printing and typesetting",
        img: "blog-2.png",
        link: "See cases using Unity",
      },
    ],
  },
  careers: {
    title: "Careers",
    data: [
      {
        position: "Front end developer",
        subtitle: "full time, remote",
        tags: [
          "CSS",
          "Excellent knowledge of JS (ES6) / TypeScipt",
          "Good knowledge of Redux and Webpack",
        ],
        description:
          "Also is nice to have: Good communication skills, Strong English, React Native skills, Experience with SQL or NoSQL databases, Experience with Firebase, Experience with Redux. \n\nWhat you will be doing: Development of new functionality which our clients are interested in Creating the new solutions, making improvements and optimizations of existing solutions, Writing tests, Writing Documentation, Development of a completely new product based on the existing one (Med Biotech sphere)",
      },
      {
        position: "UI/UX designer",
        subtitle: "part time, remote",
        tags: [
          "CSS",
          "Excellent knowledge of JS (ES6) / TypeScipt",
          "Good knowledge of Redux and Webpack",
        ],
        description:
          "Also is nice to have: Good communication skills, Strong English, React Native skills, Experience with SQL or NoSQL databases, Experience with Firebase, Experience with Redux. \n\nWhat you will be doing: Development of new functionality which our clients are interested in Creating the new solutions, making improvements and optimizations of existing solutions, Writing tests, Writing Documentation, Development of a completely new product based on the existing one (Med Biotech sphere)",
      },
      {
        position: "Front end developer",
        subtitle: "full time, remote",
        tags: [
          "CSS",
          "Excellent knowledge of JS (ES6) / TypeScipt",
          "Good knowledge of Redux and Webpack",
        ],
        description:
          "Also is nice to have: Good communication skills, Strong English, React Native skills, Experience with SQL or NoSQL databases, Experience with Firebase, Experience with Redux. \n\nWhat you will be doing: Development of new functionality which our clients are interested in Creating the new solutions, making improvements and optimizations of existing solutions, Writing tests, Writing Documentation, Development of a completely new product based on the existing one (Med Biotech sphere)",
      },
      {
        position: "UI/UX designer",
        subtitle: "part time, remote",
        tags: [
          "CSS",
          "Excellent knowledge of JS (ES6) / TypeScipt",
          "Good knowledge of Redux and Webpack",
        ],
        description:
          "Also is nice to have: Good communication skills, Strong English, React Native skills, Experience with SQL or NoSQL databases, Experience with Firebase, Experience with Redux. \n\nWhat you will be doing: Development of new functionality which our clients are interested in Creating the new solutions, making improvements and optimizations of existing solutions, Writing tests, Writing Documentation, Development of a completely new product based on the existing one (Med Biotech sphere)",
      },
      {
        position: "Front end developer",
        subtitle: "full time, remote",
        tags: [
          "CSS",
          "Excellent knowledge of JS (ES6) / TypeScipt",
          "Good knowledge of Redux and Webpack",
        ],
        description:
          "Also is nice to have: Good communication skills, Strong English, React Native skills, Experience with SQL or NoSQL databases, Experience with Firebase, Experience with Redux. \n\nWhat you will be doing: Development of new functionality which our clients are interested in Creating the new solutions, making improvements and optimizations of existing solutions, Writing tests, Writing Documentation, Development of a completely new product based on the existing one (Med Biotech sphere)",
      },
    ],
  },
  contactUs: {
    title: "Contact Us",
    text: "Fill up the form and our team will get back to you within 12 hour or:",
    socialNetwork: [
      { icon: "email.svg", link: "" },
      { icon: "twitter.svg", link: "" },
      { icon: "instagram.svg", link: "" },
      { icon: "medium.svg", link: "" },
      { icon: "linkedin.svg", link: "" },
      { icon: "upwork.svg", link: "" },
      { icon: "facebook.svg", link: "" },
    ],
  },
};

export const navigation = [
  { title: "Intro", name: "" },
  { title: "Products", name: "Our Products" },
  { title: "Statistic", name: "Statistic" },
  { title: "Portfolio", name: "Portfolio" },
  { title: "Skills", name: "Skills" },
  { title: "Feedback", name: "Feedback" },
  { title: "Team", name: "Team" },
  { title: "Blog", name: "Blog" },
  { title: "Careers", name: "Careers" },
  { title: "ContactUs", name: "Contact Us" },
];
